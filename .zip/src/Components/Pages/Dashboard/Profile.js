import React from "react";

const Profile = () => {
  return (
    <div style={{ backgroundColor: "white", color: "black", height: "100vh" }}>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia
      exercitationem quis, in voluptatum, expedita explicabo optio laborum sed
      aperiam aut repudiandae, excepturi saepe illum ipsum perspiciatis
      doloribus fuga quo cupiditate.
    </div>
  );
};

export default Profile;
